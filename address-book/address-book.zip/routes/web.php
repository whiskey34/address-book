<?php

use Illuminate\Support\Facades\Route;

// Route::get('/', function () {
//     return view('server');
// });

Route::get('/{any}', function () {
    return view('index');
})->where('any', '.*');
